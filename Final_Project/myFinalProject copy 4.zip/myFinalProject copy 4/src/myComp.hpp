//
//  myComp.hpp
//  myFinalProject
//
//  Created by Sally Mallat on 03/03/2022.
//

#ifndef myComp_hpp
#define myComp_hpp


#include <stdio.h>
#include "ofMain.h"

// bubbles --> Parent Class

// All other classes will be derived from this
// class NOT ofApp class. This is because if I
// make a class from ofApp, it will override
// the existing draw function and the file won't
// compile or won't work!

// -----------------------------------------------------------------
// BUBBLES CLASS ---------------------------------------------------
// -----------------------------------------------------------------

class bubbles {
    
    public:
        
        bubbles();
    
        virtual void setup();
        virtual void update();
        virtual void draw();
        
        virtual void mousePressed(int x, int y, int button);
        virtual void mouseReleased(int x, int y, int button);

        float theta;
        float amplitude;
        float frequency;

        float translate;
        float time;

        int x;
        int y;
    
        float centerX;
        float centerY;
    
        //ofShader shader;

    


};

// -----------------------------------------------------------------
// WAVES CLASS -----------------------------------------------------
// -----------------------------------------------------------------

class waves : bubbles {
    
    public:
        
        waves();
    
        void setup();
        void update();
        void draw();
        ofEasyCam camera;

};


// -----------------------------------------------------------------
// WAVES2 CLASS -----------------------------------------------------
// -----------------------------------------------------------------

class wavesMimic : bubbles {
    
    public:
        
    wavesMimic();
    
        void setup();
        void update();
        void draw();
        ofEasyCam camera;

};



#endif /* myComp_hpp */
