// ofApp will include ONLY structural script
// that will apply to the entire project.
//
// The bulk of the code will go into
// multiple classes to make it easier
// to understand and follow.

#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    ofBackground(0, 0, 0);
    ofSetCircleResolution(100);

    ofSetFrameRate(60); // 60 FPS for now

    centerX = ofGetWidth()/2;
    centerY = ofGetHeight()/2;
    
    //Sound Setup
//    synth.load("sound2.wav");
//    drum.load("jdee_beat.mp3");
//    synth.setVolume(0.75f);
//    drum.setVolume(0.75f);

    gui.setup();
    gui.add(playPause.setup("FREEZE!!!", false));
    gui.add(soundPlay.setup("SOUND", false));

    mySpace.setup();


}

//--------------------------------------------------------------
void ofApp::update(){

//    ofSoundUpdate();
    mySpace.update();


}

//--------------------------------------------------------------
void ofApp::draw(){

    //GUI Elements
    ofPushMatrix();
        if (playPause) {
            ofResetElapsedTimeCounter();
        }
        if (soundPlay) {
            

        }
        gui.draw();
    ofPopMatrix();

    //Calling classes at different intervals
    ofPushMatrix();
    
        //To be disabled later
        ofEnableDepthTest();
    
        //Frames 0 to 500
        if (ofGetFrameNum() > 0 && ofGetFrameNum() < 500) {
//
//            synth.play();
//            synth.setSpeed(1.0f);

        //Adding Folios
        ofPushMatrix();
                ofSetColor(120, 255, 100);
                ofTranslate(250, 0);
                ofDrawBitmapString("Advanced Coding #2 / Final Project / By Sali Mallat / 20040127 \n>>> Move your MOUSE around!", 15, 20);
        ofPopMatrix();

        //Calling Bubbles Objects
        ofPushMatrix();
            myBubbles1.draw();

            ofScale(0.5);
            ofTranslate(0, centerY);
            myBubbles2.draw();
        ofPopMatrix();
            

        }
    
        //Frames 500 to 1000
        else if (ofGetFrameNum() > 500 && ofGetFrameNum() < 1000) {
         
//            drum.play();
//            drum.setSpeed(1.0f);
        //Adding Folios
        ofPushMatrix();
                ofSetColor(120, 255, 100);
                ofTranslate(250, 0);
                ofDrawBitmapString("Advanced Coding #2 / Final Project / By Sali Mallat / 20040127 \n>>> MOVE / DRAG / ZOOM!", 15, 20);
        ofPopMatrix();

        //Calling Waves Objects
        ofPushMatrix();
                myWaves1.draw();
        ofPopMatrix();
        }
    
        //Frames 1000 to 1500
        else if (ofGetFrameNum() > 1000 && ofGetFrameNum() < 1500) {
            
            //Adding Folios
            ofPushMatrix();
                ofSetColor(120, 255, 100);
                ofTranslate(250, 0);
                ofDrawBitmapString("Advanced Coding #2 / Final Project / By Sali Mallat / 20040127 \n>>> MOVE / DRAG / ZOOM!", 15, 20);
            ofPopMatrix();

            //Calling Space Objects
            ofPushMatrix();
                mySpace.draw();
            ofPopMatrix();
        }
    
        //Frames >1500
        else if (ofGetFrameNum() > 1500) {

            //mySpace.draw();

            //myyyWaves.draw();
        }

    
        ofDisableDepthTest();
    ofPopMatrix();



}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
