//
//  myComp.cpp
//  myFinalProject
//
//  Created by Sally Mallat on 03/03/2022.
//

#include "myComp.hpp"


// -----------------------------------------------------------------
// BUBBLES CLASS ---------------------------------------------------
// -----------------------------------------------------------------

bubbles::bubbles() {
    
}

void bubbles::setup() {
    ofSetBackgroundAuto(true);

    
}

void bubbles::update() {

}

void bubbles::draw() {
    
    theta = theta + .03;
    amplitude = 300;
    frequency = 0.01;
    
    
    time = ofGetElapsedTimef();
    
    //ofSetLineWidth(2);
    //ofSetColor(10 * time, 20 * time , 237);

    ofPushMatrix();
        ofNoFill();
        ofSetLineWidth(2);
        ofSetColor(255);
        for (int i = 0; i < ofGetWindowWidth(); i++) {
            
            translate = amplitude * sin(i * frequency + time);
            ofDrawCircle(i * sin(tan(i) * 0.08 + time), ofGetHeight()/2 + translate, 100 * sin(tan(i)*0.01));
            
        }

        for (int i = 0; i < ofGetWindowWidth(); i++) {
            ofDrawCircle(i * sin(tan(i) * 0.08 + time), ofGetHeight()/2 + amplitude * cos(i * frequency + time), 100 * sin(tan(i)*0.01));
        }
    ofPopMatrix();
    
        ofFill();
        //ofSetColor(ofGetMouseX(), ofGetMouseY(), time);
        for (int i = 0; i < ofGetWindowWidth(); i++) {
            
            ofSetColor(100 + ofGetMouseX() * sin(i * 0.01 + time),
                       50 + ofGetMouseX() * sin(i * 0.011 + time),
                       50 + ofGetMouseX() * sin(i * 0.012 + time));
            
            translate = amplitude * sin(i * frequency + time);
            ofDrawCircle(i * sin(tan(i) * 0.08 + time), ofGetHeight()/2 + translate, 100 * sin(tan(i)*0.01));
            
        }

        for (int i = 0; i < ofGetWindowWidth(); i++) {
            
            ofSetColor(100 + ofGetMouseX() * sin(i * 0.01 + time),
                       50 + ofGetMouseX() * sin(i * 0.011 + time),
                       50 + ofGetMouseX() * sin(i * 0.012 + time));
            
            ofDrawCircle(i * sin(tan(i) * 0.08 + time), ofGetHeight()/2 + amplitude * cos(i * frequency + time), 100 * sin(tan(i)*0.01));
        }
    
}

//--------------------------------------------------------------
void bubbles::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void bubbles::mouseReleased(int x, int y, int button){

}


// -----------------------------------------------------------------
// WAVES CLASS -----------------------------------------------------
// -----------------------------------------------------------------

waves::waves() {
    
}

void waves::setup() {
    
}

void waves::update() {
    
}

void waves::draw() {
    
camera.begin();
    
    ofTranslate(-300, -250);
    
    time = ofGetElapsedTimef();
    centerX = ofGetWidth()/2;
    centerY = ofGetHeight()/2;
    
    ofFill();
    
    for (int x = 1; x < 20; x++) {
     
        for (int i = 0; i < 900; i++) {
            
            ofPushMatrix();
            ofSetColor(100 + ofGetMouseX() * sin(i * 0.01 + time),
                       50 + ofGetMouseX() * sin(i * 0.011 + time),
                       50 + ofGetMouseX() * sin(i * 0.012 + time));
            
            ofDrawSphere(i,
                         50 * x + 100 * cos( i * tan(0.01) + time + x),
                         50 * x + ofGetMouseY()/10 * sin( i * cos( i * tan(0.01) + time + x) + time * 0.5) ,
                         sin( i * 0.005 + time + x));
            ofPopMatrix();
        }
    }
    
camera.end();
}


wavesMimic::wavesMimic() {
    
}

void wavesMimic::setup() {
    
}

void wavesMimic::update() {
    
}


void wavesMimic::draw() {
    
camera.begin();
    
    ofTranslate(-300, -250);
    
    time = ofGetElapsedTimef();
    centerX = ofGetWidth()/2;
    centerY = ofGetHeight()/2;
    
    
    
    ofFill();
    

     
        for (int i = 0; i < 500; i++) {
            
            ofPushMatrix();
            //ofRotateDeg(45 * time);
            ofSetColor(100 + ofGetMouseX() * sin(i * 0.01 + time),
                       50 + ofGetMouseX() * sin(i * 0.011 + time),
                       50 + ofGetMouseX() * sin(i * 0.012 + time));
            
            float x1 = tan(TWO_PI / 1000 * i * (ofGetMouseX()/50)) * cos(TWO_PI / 1000 * i * (ofGetMouseY()/50)) * 200;
            
            float y1 = tan(TWO_PI / 1000 * i * (ofGetMouseX()/50)) * sin(TWO_PI / 1000 * i * (ofGetMouseY()/50)) * 200;
            
            float z1 = sin(TWO_PI / 1000 * i * (ofGetMouseX()/50)) * cos(TWO_PI / 1000 * i * (ofGetMouseY()/50)) * 200;
                        // 10 + sin( i * 0.005 + time + x));
            ofVertex(x1,y1,z1);
            ofPopMatrix();
        }

    
camera.end();
}
